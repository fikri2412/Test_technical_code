﻿using System.Collections.Generic;

namespace Test_technical_code.Models
{
    public class ViewModel
    {
        public List<Number> ListResult {  get; set; } 

    }

    public class Number
    {

        public int number { get; set; }

    }

}
