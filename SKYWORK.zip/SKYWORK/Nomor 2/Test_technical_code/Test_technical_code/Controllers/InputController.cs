﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Test_technical_code.Models;

namespace Test_technical_code.Controllers
{
    public class InputController : Controller
    {
        public IActionResult InputData(string param)
        {

            ViewModel model = new ViewModel();
            List<Number> list= new List<Number>();

            if(param != null)
            {
                int numberline = param.Length;
                char[] charr = new char[param.Length];

                string zero = "";
                for (int i = 0; i < param.Length; i++)
                {
                    charr[i] = param[i];
                }




                for (int i = 0; i < numberline; i++)
                {
                    Number number = new Number();
                    for (int a = 0; a < i + 1; a++)
                    {
                        zero += "0";
                    }
                    number.number = int.Parse(charr[i].ToString() + zero);
                    list.Add(number);
                    zero = "";
                }

            }
            else
            {
                model.ListResult = new System.Collections.Generic.List<Number>();
            }
            model.ListResult = list;
            return View(model);

        }
    }
}
